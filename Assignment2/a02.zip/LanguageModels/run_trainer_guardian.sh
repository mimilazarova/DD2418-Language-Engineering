#!/bin/sh
python BigramTrainer.py -f data/guardian_training.txt -d guardian_model.txt
