#!/bin/sh
python BigramTester.py -f austen_model.txt -t data/guardian_test.txt
