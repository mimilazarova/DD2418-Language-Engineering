#!/bin/sh
python BigramTrainer.py -f data/small.txt -d small_model.txt
