#!/bin/sh
python dep_parser.py -s "John made the pie in the fridge"
