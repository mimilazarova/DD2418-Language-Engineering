#!/bin/sh
python CKY.py --grammar grammar2.txt --input_sentence "time flies like an arrow" --print_trees --symbol NP

